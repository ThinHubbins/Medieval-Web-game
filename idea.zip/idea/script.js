const funQuests = [
    'Find a random object in your room and create a funny story about it.',
    'Dance to your favorite song and share the video with friends.',
    'Draw a doodle that represents your current mood and share it on social media.',
    'Come up with a silly and imaginative name for a new ice cream flavor.',
    'Create a short, funny skit and perform it for your friends or family.'
];

let userLevel = 1; // Initial level
const maxLevel = 100; // Maximum level

// Construct the file URIs for the sounds
const popSoundPath = 'file:///C:/Users/USER/Desktop/idea/pop.mp3'; // Replace 'pop.mp3' with your actual sound file name
const bgMusicPath = 'file:///C:/Users/USER/Desktop/idea/bg_music.mp3'; // Replace 'bg_music.mp3' with your actual background music file name

// Create audio elements for the sounds
const popSound = new Audio(popSoundPath);
const bgMusic = new Audio(bgMusicPath);

let progressInterval; // Variable to store the progress interval

function generateFunQuest() {
    const randomFunQuest = funQuests[Math.floor(Math.random() * funQuests.length)];
    return randomFunQuest;
}

function openModal() {
    const questContent = document.getElementById('quest-content');
    questContent.textContent = generateFunQuest();

    // Play the pop sound
    popSound.play();

    // Reset the progress bar
    resetProgressBar();

    const modal = document.getElementById('quest-modal');
    modal.style.display = 'flex';
}

function closeModal() {
    const modal = document.getElementById('quest-modal');
    modal.style.display = 'none';

    // Clear the progress interval when the modal is closed
    clearInterval(progressInterval);

    // Update the user level on the home page with animation
    updateLevel();
}

function resetProgressBar() {
    const progressBar = document.getElementById('progress-bar');
    progressBar.style.width = '0';
}

function acceptQuest() {
    const progressBar = document.getElementById('progress-bar');
    const acceptButton = document.getElementById('accept-btn');

    // Set the progress bar to be visible
    progressBar.style.visibility = 'visible';

    // Change the button text to "Accepted"
    acceptButton.textContent = 'Accepted';

    // Disable the "Accept Quest" button to prevent multiple clicks
    acceptButton.disabled = true;

    // Increment the user level
    userLevel++;

    // Ensure the user level does not exceed the maximum level
    userLevel = Math.min(userLevel, maxLevel);

    // Update the progress bar and level
    updateProgressAndLevel();
}

function updateProgressAndLevel() {
    const progressBar = document.getElementById('progress-bar');

    // Increment the progress bar every second (adjust the duration as needed)
    let progressValue = 0;
    const duration = 10; // seconds
    const increment = 100 / duration;

    progressInterval = setInterval(() => {
        progressValue += increment;
        progressBar.style.width = `${progressValue}%`;

        // When the progress reaches 100%, clear the interval
        if (progressValue >= 100) {
            clearInterval(progressInterval);

            // Close the modal after clearing the interval
            closeModal();
        }
    }, 1000);

    // Update the user level on the home page with animation
    updateLevel();

    // Revert the "Accept Quest" button text after a short delay
    setTimeout(() => {
        const acceptButton = document.getElementById('accept-btn');
        acceptButton.textContent = 'Accept Quest';
        acceptButton.disabled = false;  // Enable the button
    }, 10000); // Adjust the delay as needed
}


function updateLevel() {
    const levelElement = document.getElementById('user-level');

    // Add a class to trigger the animation
    levelElement.classList.add('level-up-animation');

    // Update the level text
    levelElement.textContent = `Level: ${userLevel}`;

    // Remove the animation class after a short delay
    setTimeout(() => {
        levelElement.classList.remove('level-up-animation');
    }, 1000); // Adjust the delay as needed
}

// Play background music when the page loads
bgMusic.loop = true; // Loop the background music
bgMusic.volume = 0.5; // Set the volume (0.0 to 1.0)
bgMusic.play();

document.getElementById('generate-btn').addEventListener('click', function () {
    openModal();
});
