// You can add JavaScript functionality here
console.log('Script loaded');

// Example: Add an event listener to a button
document.addEventListener('DOMContentLoaded', function () {
    const startQuestButton = document.getElementById('startQuestButton');
    const backToMainPageButton = document.getElementById('backToMainPageButton');

    startQuestButton.addEventListener('click', function () {
        alert('Quest started! Prepare for your adventure!');
    });

    backToMainPageButton.addEventListener('click', function () {
        window.location.href = 'index.html'; // Replace 'index.html' with the actual main page file
    });
});
